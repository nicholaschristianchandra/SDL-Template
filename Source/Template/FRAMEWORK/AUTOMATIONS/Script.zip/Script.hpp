#pragma once

#include <Framework/Framework.hpp>

namespace $safeitemname$
{
}
